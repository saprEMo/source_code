LC_funcE_stableNS_orig_p9995_7LC.txt #original data 
LC_funcE_stableNS_1000p_7LC.txt	#original data reduced to 1000 points per LC to speed up
LC_funcE_stableNS_1000p_7LC_scaled0.059596.txt #same, but luminosity rescaled to match the transient Bauer et al 2017
